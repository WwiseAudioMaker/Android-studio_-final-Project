package com.zybooks.inventoryapp_uidesign;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText etItemId, etItemName, etItemAvailable, etItemCost, etItemOrder;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        etItemId = findViewById(R.id.etItemId);
        etItemName = findViewById(R.id.etItemName);
        etItemAvailable = findViewById(R.id.etItemAvailable);
        etItemCost = findViewById(R.id.etItemCost);
        etItemOrder = findViewById(R.id.etItemOrder);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered data
                String itemId = etItemId.getText().toString();
                String itemName = etItemName.getText().toString();
                String itemAvailable = etItemAvailable.getText().toString();
                String itemCost = etItemCost.getText().toString();
                String itemOrder = etItemOrder.getText().toString();

                // Create an Intent to pass data back to DataDisplayActivity
                Intent intent = new Intent();
                intent.putExtra("itemId", itemId);
                intent.putExtra("itemName", itemName);
                intent.putExtra("itemAvailable", itemAvailable);
                intent.putExtra("itemCost", itemCost);
                intent.putExtra("itemOrder", itemOrder);
                setResult(RESULT_OK, intent);
                finish(); // Close AddItemActivity
            }
        });
    }
}

