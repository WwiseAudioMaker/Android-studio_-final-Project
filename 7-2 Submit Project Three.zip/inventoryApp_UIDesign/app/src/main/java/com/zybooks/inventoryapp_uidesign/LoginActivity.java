package com.zybooks.inventoryapp_uidesign;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnSubmit, btnNewLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.editTextTextPassword2);
        btnSubmit = findViewById(R.id.button);
        btnNewLogin = findViewById(R.id.button2);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle login button click
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                // Check if username and password are valid
                if (isValidCredentials(username, password)) {
                    // Proceed to main app screen or activity
                    // You can use an Intent here to start a new activity
                } else {
                    // Show error message for invalid credentials
                    Toast.makeText(LoginActivity.this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnNewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle new login button click
                // Start NewLoginActivity
            }
        });
    }

    // Method to validate credentials against the database
    private boolean isValidCredentials(String username, String password) {
        // Implement your logic here to validate against the database
        // Return true if valid, false otherwise
        return false; // Placeholder return value
    }
}
