package com.zybooks.inventoryapp_uidesign;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etEmployeeId, etPassword;
    private Button btnLogin, btnNewLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmployeeId = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.editTextTextPassword2);
        btnLogin = findViewById(R.id.button);
        btnNewLogin = findViewById(R.id.btnNewLogin); // Initialize the New Login button

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle login button click
                String employeeId = etEmployeeId.getText().toString();
                String password = etPassword.getText().toString();

                // Check if username and password are valid
                if (isValidCredentials(employeeId, password)) {
                    // If valid, navigate to DataDisplayActivity
                    Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                    startActivity(intent);
                } else {
                    // Show error message for invalid credentials
                    Toast.makeText(MainActivity.this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Add OnClickListener for the New Login button
        btnNewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to NewLoginActivity
                Intent intent = new Intent(MainActivity.this, NewLoginActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to validate credentials
    private boolean isValidCredentials(String employeeId, String password) {
        // Implement your logic here to validate the credentials
        // Check if the entered employeeId and password match the expected values
        return employeeId.equals("0768161") && password.equals("Trabajo@5");
    }
}
