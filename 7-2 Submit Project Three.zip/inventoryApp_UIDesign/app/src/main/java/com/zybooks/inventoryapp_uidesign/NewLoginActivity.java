package com.zybooks.inventoryapp_uidesign;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;

public class NewLoginActivity extends AppCompatActivity {

    private EditText etNewUsername, etNewPassword;
    private Button btnCreateNewLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_login);

        etNewUsername = findViewById(R.id.etUsername);
        etNewPassword = findViewById(R.id.editTextTextPassword2);
        btnCreateNewLogin = findViewById(R.id.button);

        btnCreateNewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle create new login button click
                String newUsername = etNewUsername.getText().toString();
                String newPassword = etNewPassword.getText().toString();

                // Check if fields are not empty
                if (!TextUtils.isEmpty(newUsername) && !TextUtils.isEmpty(newPassword)) {
                    // Save the new login to the database (Use Room or other database methods)
                    // Show success message to user
                    // For example, call a method to insert data into the database
                    insertNewLogin(newUsername, newPassword);
                    Toast.makeText(NewLoginActivity.this, "New login created successfully.", Toast.LENGTH_SHORT).show();
                } else {
                    // Show error message for empty fields
                    Toast.makeText(NewLoginActivity.this, "Please enter valid credentials.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to insert new login into the database
    private void insertNewLogin(String username, String password) {
        // Implement your database insertion logic here
        // For example, using Room Database to insert new login
        // You would typically call a method from your AppDatabase class here
        // For example: AppDatabase.getInstance(getApplicationContext()).foodItemDao().insertFoodItem(new FoodItem(username, password));
    }
}
