package com.zybooks.inventoryapp_uidesign;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PermissionPromptActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textPermissionPrompt, textPermissionDescription;
    private Button btnGrantPermission;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_prompt);

        imageView = findViewById(R.id.imageView);
        textPermissionPrompt = findViewById(R.id.textPermissionPrompt);
        textPermissionDescription = findViewById(R.id.textPermissionDescription);
        btnGrantPermission = findViewById(R.id.btnGrantPermission);

        // Set up your UI components and handle button clicks
    }
}
