package com.zybooks.inventoryapp_uidesign.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {FoodItem.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase INSTANCE;

    public abstract FoodItemDao foodItemDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "app_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries() // Just for testing, remove in production
                    .build();

            insertTestData(); // Insert test data
        }
        return INSTANCE;
    }

    private static void insertTestData() {
        new Thread(() -> {
            FoodItemDao foodItemDao = INSTANCE.foodItemDao();

            // Insert a test FoodItem
            FoodItem foodItem = new FoodItem();
            foodItem.itemName = "Test Item";
            foodItem.available = 10;
            foodItem.cost = 9.99;
            foodItemDao.insertFoodItem(foodItem);

            // Insert a test login
            FoodItem loginItem = new FoodItem();
            loginItem.itemName = "snhu"; // Employee ID
            loginItem.available = 0; // Not used for employee ID
            loginItem.cost = 0.0; // Not used for employee ID
            foodItemDao.insertFoodItem(loginItem);

            // Insert a test password
            FoodItem passwordItem = new FoodItem();
            passwordItem.itemName = "12345"; // Password
            passwordItem.available = 0; // Not used for password
            passwordItem.cost = 0.0; // Not used for password
            foodItemDao.insertFoodItem(passwordItem);
        }).start();
    }
}
