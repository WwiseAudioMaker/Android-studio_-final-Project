package com.zybooks.inventoryapp_uidesign.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface FoodItemDao {
    @Insert
    void insertFoodItem(FoodItem foodItem);

    @Query("SELECT * FROM food_items")
    List<FoodItem> getAllFoodItems();

    // Add more method declarations as needed
}
