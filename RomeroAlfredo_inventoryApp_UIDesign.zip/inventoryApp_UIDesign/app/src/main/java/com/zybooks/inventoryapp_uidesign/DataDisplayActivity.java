package com.zybooks.inventoryapp_uidesign;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DataItemAdapter adapter;
    private List<DataItem> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create a list of DataItems with your data (e.g., from a database)
        dataList = getDataList();

        // Create and set the adapter
        adapter = new DataItemAdapter(dataList);
        recyclerView.setAdapter(adapter);
    }

    // Helper method to create a list of DataItem objects
    private List<DataItem> getDataList() {
        // Your logic to fetch the data from a database or any other source
        // ...

        // For example, dummy data for demonstration purposes:
        List<DataItem> dataList = new ArrayList<>();
        dataList.add(new DataItem("001", "chicken", "10", "5.99", "3"));
        dataList.add(new DataItem("002", "steak", "5", "12.49", "2"));
        // Add more data items as needed

        return dataList;
    }
}


