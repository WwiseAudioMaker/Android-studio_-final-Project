package com.zybooks.inventoryapp_uidesign;

public class PermissionPromptActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_prompt);

        // TODO: Add logic for handling permission request button click
    }
}

